import React from 'react';
import Dashboard from './components/Dashboard'

function App() {
  return (
    <React.Fragment>
      <Dashboard />
    </React.Fragment>
  );
}

export default App;
