import React from "react";
// import styled from "styled-components";
import {Bar} from 'react-chartjs-2';


class Dashboard extends React.Component {
  state = {
    labels: null,
    datasets: [
      {
        data: []
      }
    ],
    numberResults: null,
    disclaimer: null
  }

  async componentDidMount() {
    const response = await fetch(`https://api.fda.gov/device/recall.json?search=product_code:MQG&limit=1000`);
    const json = await response.json();
    const data = {}

    // populate set labels and object data labels count
    json.results.map(result => {
      if (data[result.product_res_number]) {
        // console.log('hi')
        data[result.product_res_number] += 1
      } else {
        data[result.product_res_number] = 1
      }

    })
    this.setState({
      ...this.state,
      numberResults: json.meta.results.total,
      disclaimer: json.meta.disclaimer,
      labels: Object.keys(data),
      datasets: [ {
        // label: 'MQG Products By Code-Year',
        backgroundColor: 'rgba(255,99,132,0.2)',
        borderColor: 'rgba(255,99,132,1)',
        borderWidth: 1,
        hoverBackgroundColor: 'rgba(255,99,132,0.4)',
        hoverBorderColor: 'rgba(255,99,132,1)',
        barPercentage: 0.5,
        minBarLength: 0,
        data: Object.values(data), 
        }
      ],
    })

  }

  render() {
      if (this.state.labels && this.state.datasets[0].data) {
        return (
          <React.Fragment>
                <h2>MQG Products from openFDA API By Code Year</h2>
                <Bar data={this.state} 
                options={{
                  legend: {
                    display: false
                  },
                  scales: {
                    yAxes: [{
                      ticks: {
                          beginAtZero: true,
                        min: 0
                        }
                      }]
                    },
                }}
                />
                <p>No. Results: {this.state.numberResults}</p>
                <p>DISCLAIMER: {this.state.disclaimer}</p>
          </React.Fragment>
        )
      } else {
        return <h2>Loading...</h2>

      }
  }
}

export default Dashboard