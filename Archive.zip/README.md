# Please NPM Install from bar-graph-openfda folder

## Screenshot Sample

![Screen Shot 2020-09-01 at 1 08 53 AM](https://user-images.githubusercontent.com/15071636/91801122-e9c60000-ebef-11ea-9475-e8515daee506.png)
